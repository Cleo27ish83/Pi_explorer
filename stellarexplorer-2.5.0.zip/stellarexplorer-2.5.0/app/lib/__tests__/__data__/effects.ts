// eslint-disable-next-line import/no-anonymous-default-export
export default [
  {
    id: '0000774537222303745-0000000002',
    account: 'GCOLHJY3DMPDSZW7PNK4RWBQMCYE5Q67W7TT44SD46RKTVDEAUJZTNE6',
    type: 'account_debited',
    typeI: 3,
    createdAt: '2018-10-15T03:06:14Z',
    assetType: 'credit_alphanum4',
    assetCode: 'HNY',
    assetIssuer: 'GCOLHJY3DMPDSZW7PNK4RWBQMCYE5Q67W7TT44SD46RKTVDEAUJZTNE6',
    amount: '1000000000.0000000',
  },
  {
    id: '0000773746948313089-0000000003',
    account: 'GCOLHJY3DMPDSZW7PNK4RWBQMCYE5Q67W7TT44SD46RKTVDEAUJZTNE6',
    type: 'signer_created',
    typeI: 10,
    createdAt: '2018-10-15T02:50:22Z',
    weight: 1,
    publicKey: 'GCOLHJY3DMPDSZW7PNK4RWBQMCYE5Q67W7TT44SD46RKTVDEAUJZTNE6',
    key: '',
  },
  {
    id: '0000773746948313089-0000000001',
    account: 'GCOLHJY3DMPDSZW7PNK4RWBQMCYE5Q67W7TT44SD46RKTVDEAUJZTNE6',
    type: 'account_created',
    typeI: 0,
    createdAt: '2018-10-15T02:50:22Z',
    startingBalance: '10000.0000000',
  },
]
