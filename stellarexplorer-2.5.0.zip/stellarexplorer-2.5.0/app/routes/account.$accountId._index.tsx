import BalanceTab, { loader } from './account.$accountId.balances'

export { BalanceTab as default, loader }
