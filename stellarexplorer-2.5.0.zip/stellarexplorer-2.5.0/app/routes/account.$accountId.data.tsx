import { nameValueLoader, nameValueAccountTab } from './lib/name-value-table'

export const loader = nameValueLoader

export default nameValueAccountTab('Data')
