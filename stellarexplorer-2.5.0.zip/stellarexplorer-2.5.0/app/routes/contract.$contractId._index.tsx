import StorageTab, { loader } from './contract.$contractId.storage'

export { StorageTab as default, loader }
